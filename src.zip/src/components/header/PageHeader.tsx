import { HeaderDecoration } from '../decorative/Shapes';

export default function PageHeader() {
    return (
        <div className="relative w-full">
            <HeaderDecoration />
        </div>
    );
}