export function AILogo() {
    return (
        <div className="mx-auto w-32 h-32">
            <svg viewBox="0 0 100 100" className="w-full h-full">
                {/* Your circuit tree logo */}
            </svg>
        </div>
    );
}